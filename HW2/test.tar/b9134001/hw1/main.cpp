#include "main.h"

int main(int argn, char **argv) {
    TarFile tar;

    if(argn != 2) {
	usage(argv[0]);
	return 0;
    }

    if(tar.open(argv[1])) {
	tar.hexdump(cout);
	tar.close();
    }
    else
	cerr << "File opening error.\n";

    return 0;
}

void usage(char *prog) {
    cout << prog << " FileName\n";
}


#ifndef MAIN_H
#define MAIN_H

#include "tarfile.h"
#include <iostream>

using std::cerr;
using std::cout;

void usage(char* program_name);

#endif

#ifndef TARFILE_H
#define TARFILE_H

#include <iostream>
#include <iomanip>
#include <fstream>

using std::cin;
using std::cout;
using std::endl;
using std::fstream;
using std::ostream;
using std::ios;
using std::setw;
using std::setfill;
using std::hex;

//tarfile.cpp
class TarFile {
    private:
    	static const int FNAME_LEN = 1024;
	char filename[FNAME_LEN];
	fstream file;
	int value(char ch);

    public:
	TarFile();
	TarFile(char *fname);
	~TarFile();
	int open(char *fname);
	void close();
	int hexdump(ostream &output_stream);
};

#endif

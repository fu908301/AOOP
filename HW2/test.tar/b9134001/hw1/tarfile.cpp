#include "tarfile.h"

TarFile::TarFile() {
    filename[0]='\0';
}

TarFile::TarFile(char *s) {

    file.open(s, ios::in|ios::binary);

    if(!file.good())
	filename[0]='\0';
    else {
	//Prevent overflow
	strncpy(filename, s, FNAME_LEN);
	filename[FNAME_LEN-1] = '\0';
    }

}

TarFile::~TarFile() {
    if(file.good())
	file.close();
}

int TarFile::open(char *s) {

    if(file.good())
	file.close();
    file.open(s, ios::in|ios::binary);

    if(!file.good())
	filename[0]='\0';
    else {
	//Prevent overflow
	strncpy(filename, s, FNAME_LEN);
	filename[FNAME_LEN-1] = '\0';
    }

    return file.good();
}

void TarFile::close() {
    file.close();
    filename[0]='\0';
}

int TarFile::value(char ch) {
	return static_cast<unsigned int>(*reinterpret_cast<unsigned char*>(&ch));
}

int TarFile::hexdump(ostream &os) {
    unsigned int offset=0;
    char buffer[16];

    if(!file.good())
	return -1;

    for(file.read(buffer, 16);file.gcount();file.read(buffer, 16)) {
	int i, j;

	//Print memory location
	os << setw(7) << setfill('0') << offset << ": ";
	offset += file.gcount();

	//Print HEX Values
	for(i=0;i<8;i++) {
	    if(file.gcount() >= (i+1)*2) {
		os << setw(2) << setfill('0') << hex << value(buffer[i*2]);
		os << setw(2) << setfill('0') << hex << value(buffer[i*2+1]);
	    }
	    else if(file.gcount() >= i*2+1) {
		os << setw(2) << setfill('0') << hex << value(buffer[i*2]) << "  ";
	    }
	    else
		os << "    ";
	    os.put(' ');
	}

	//Print Human readable part
	os.put(' ');
	for(i=0;i<16&&i<file.gcount();i++) {
	    if(isprint(buffer[i]))
		os.put(buffer[i]);
	    else
		os.put('.');
	}
	os << endl;
    }
    return 0;
}

